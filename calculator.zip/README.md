# React Calculator (5b8d0fd276b6d288905ed2f63a934e057e8feca2)


## To install

Please ensure you have NPM/Node installed and run `npm run install`. Once that is completed run `npm run dev` This should create a localhost envionrment  (typically http://localhost:8080/) - see terminal for the address

## To run tests 

Use `npm run test` this will run the tests, but if you prefer to have the tests being watched use `npm run test:watch`
